# Language-Translator
A Language Translator which can translate from one language to any other language .It's also have feature like it also can read the translated language for the user .

![Screenshot (74)](https://user-images.githubusercontent.com/68509017/118517126-93382c00-b754-11eb-9dd8-0aa4028ad298.png)



This is the interface of the Language Translator. This is made by using tkinter Frame-work .
User have to select the source language from top left corner and destination language from top right corner .
Then user have to enter the text in selected soruce language and click on translate button , this button will
change it's color for every sucessfull click and user get the output on the bottom box . 
If user what to lisent the translated text then he/she have to click on the speak button .




![Screenshot (73)](https://user-images.githubusercontent.com/68509017/118516897-5e2bd980-b754-11eb-8e75-7eeeb7c4eb83.png)


This is the example of how this application will work . 
Here it will translate from source language English to Destination language hindi.
